package com.nxpert.CustomerDemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CustomerDemoManyToManyApplication {

	public static void main(String[] args) {
		SpringApplication.run(CustomerDemoManyToManyApplication.class, args);
	}

}
